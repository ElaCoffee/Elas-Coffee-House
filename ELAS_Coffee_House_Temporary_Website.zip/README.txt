ELAS COFFEE HOUSE - TEMPORARY WEBSITE

FILES TO UPLOAD:
1. index.html
2. elas-coffee-house.jpg

Keep both files in the same folder when uploading.

This is a static temporary website suitable for free hosting such as GitHub Pages.
After publishing, connect www.katriye.com as the custom domain.
